from distutils.core import setup

setup(
    name           = 'normal',
    version        = '1.2.0',
    py_modules     =['normal'],
    author         = 'Rithish',
    author_email   = 'rithishvisakoti@gmail.com',
    url            = 'http://www.starthabit.com',
    description    = 'Indentation and optional arguement'
    )
